using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Linq.Expressions;

namespace mystore.Pages.client
{
    public class CreateModel : PageModel
    {
        public Clintinfo Clintinfo = new Clintinfo();
        public string errorMessage = "";
        public string successMessage = "";
        public void OnGet()
        {
        }
        public void OnPost()
        {
            Clintinfo.name = Request.Form["name"];
            Clintinfo.email = Request.Form["email"];
            Clintinfo.phone = Request.Form["phone"];
            Clintinfo.address = Request.Form["address"];
            if(Clintinfo.name.Length==0||Clintinfo.email.Length==0|| 
                Clintinfo.phone.Length==0||Clintinfo.address.Length==0)
            {
                errorMessage = "All the fields are required";
                return;
            }
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=mystore;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "insert into clints" +
                        "(name,email,phone,address) values" +
                        "(@name,@email,@phone,@address);";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("name", Clintinfo.name);
                        command.Parameters.AddWithValue("email", Clintinfo.email);
                        command.Parameters.AddWithValue("phone", Clintinfo.phone);
                        command.Parameters.AddWithValue("address", Clintinfo.address);
                        command.ExecuteNonQuery();
                    }
                }
                    }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
                
            }
            Clintinfo.name = "";
            Clintinfo.email = "";
            Clintinfo.phone = "";
            Clintinfo.address = "";
            successMessage = "New Client Added Correctly";
            Response.Redirect("/client/Index");

        }
    }
}
