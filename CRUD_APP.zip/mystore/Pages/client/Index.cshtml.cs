using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace mystore.Pages.client
{
    public class IndexModel : PageModel
    {
        public List<Clintinfo> listclints = new List<Clintinfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=mystore;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM clints";
                    using SqlCommand command = new SqlCommand(sql, connection);
                    {
                        using SqlDataReader reader = command.ExecuteReader();
                        {
                            while (reader.Read())
                            {
                                Clintinfo clintinfo = new Clintinfo();
                                clintinfo.id = "" + reader.GetInt32(0);
                                clintinfo.name = reader.GetString(1);
                                clintinfo.email = reader.GetString(2);
                                clintinfo.phone = reader.GetString(3);
                                clintinfo.address = reader.GetString(4);
                                clintinfo.created_at = reader.GetDateTime(5).ToString();
                                listclints.Add(clintinfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:  " + ex.ToString());

            }
        }
    }
    public class Clintinfo
    {
        public string id;
        public string name;
        public string email;
        public string phone;
        public string address;
        public string created_at;
    }
}
