using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace mystore.Pages.client
{
    public class editModel : PageModel
    {
        public Clintinfo clintinfo = new Clintinfo();
        public string errorMassage = "";
        public string successMessage = "";
        public void OnGet()
        {
            String id = Request.Query["id"];
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=mystore;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "select * from clints where id = @id";
                    using (SqlCommand command =new SqlCommand (sql, connection)) 
                    { 
                        command.Parameters.AddWithValue ("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader ()) 
                        {
                            if(reader.Read()) 
                            {
                               
                                clintinfo.id = "" + reader.GetInt32(0);
                                clintinfo.name = reader.GetString(1);
                                clintinfo.email = reader.GetString(2);
                                clintinfo.phone = reader.GetString(3);
                                clintinfo.address = reader.GetString(4);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                errorMassage = ex.Message;
            }
        }
        public void OnPost()
        {
            clintinfo.id = Request.Form["id"];
            clintinfo.name = Request.Form["name"];
            clintinfo.email = Request.Form["email"];
            clintinfo.phone = Request.Form["phone"];
            clintinfo.address = Request.Form["address"];

            if (clintinfo.name.Length == 0 || clintinfo.email.Length == 0 ||
                clintinfo.phone.Length == 0 || clintinfo.address.Length == 0)
            {
                errorMassage = "All the fields are required";
                return;
            }
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=mystore;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString)) 
                {
                   connection.Open();
                    string Sql = "UPDATE clints " +
                                 "SET name = @name, email = @email, phone = @phone, address = @address " +
                                  "WHERE id = @id";

                    using (SqlCommand command = new SqlCommand(Sql , connection))
                    {
                        command.Parameters.AddWithValue("@id", clintinfo.id);
                        command.Parameters.AddWithValue("@name", clintinfo.name);
                        command.Parameters.AddWithValue("@email", clintinfo.email);
                        command.Parameters.AddWithValue("@phone", clintinfo.phone);
                        command.Parameters.AddWithValue("@address", clintinfo.address);
                        

                        command.ExecuteNonQuery();

                    }

                }

            }
            catch (Exception ex)
            {

                errorMassage = ex.Message;
                return;
            }
            Response.Redirect("/client/Index"); 
        }
    }
}
